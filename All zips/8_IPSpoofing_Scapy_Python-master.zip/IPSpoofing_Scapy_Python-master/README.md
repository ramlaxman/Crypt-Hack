# IPSpoofing_Scapy_Python
This repository explains step by step procedure of how to creae an IP spoofing tool using Scapy in Python
