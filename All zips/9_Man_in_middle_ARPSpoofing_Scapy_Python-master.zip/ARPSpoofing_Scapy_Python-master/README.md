# ARPSpoofing-Scapy-Python
This repository contains code for performing Man in the Middle attack using ARP Poisioning / ARP Spoofing technique so the attacker can sniff the communications between server and victim machines using a sniffing utility like wireshark. 
