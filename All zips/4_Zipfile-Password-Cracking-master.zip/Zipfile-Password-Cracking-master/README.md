# Zipfile-Password-Cracking
This repository contains code for cracking Zipfile Passwords by perfroming a dictionary based attack.
