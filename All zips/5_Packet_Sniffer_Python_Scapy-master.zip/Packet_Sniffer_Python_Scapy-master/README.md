# Packet_Sniffer_Python_Scapy
This repository explains complete code for creating a packet sniffer similar to wireshark and filter data as we need. This repository uses scapy with python for implementation of packet sniffer.
