# WiFi-Denial-of-Service_Scapy_Python
This repository contains code for disconnecting clients connected to the targeted WiFi Access Point.
