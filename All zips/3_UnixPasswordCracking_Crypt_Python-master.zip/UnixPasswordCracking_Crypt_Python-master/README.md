# UnixPasswordCracking_Crypt_Python
This repository contains code for cracking Unix Passwords by taking hash from shadow file in linux and perfroming a dictionary based attack.
